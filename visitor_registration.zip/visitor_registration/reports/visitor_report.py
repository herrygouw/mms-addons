from odoo import models, fields, api

class VisitorReport(models.AbstractModel):
    _name = 'report.visitor_registration.visitor_report_template'
    _description = 'Visitor Report'

    @api.model
    def _get_report_values(self, docids, data=None):
        docs = self.env['visitor.registration'].browse(docids)
        return {
            'doc_ids': docids,
            'doc_model': 'visitor.registration',
            'docs': docs,
            'data': data,
        }