{
    'name': 'Visitor Registration',
    'version': '16.0.1.0.0',
    'summary': 'Manage visitor registrations',
    'description': """
        This module allows you to register and manage visitors with reporting capabilities.
    """,
    'category': 'Tools',
    'author': 'HG',
    # 'website': 'https://www.yourwebsite.com',
    'license': 'LGPL-3',
    'depends': ['base', 'web','mail'],
    'data': [
        'security/visitor_security.xml',
        'security/ir.model.access.csv',
        'views/visit_person_views.xml',
        'views/visitor_views.xml',
        'reports/visitor_report_template.xml',
    ],
    'demo': [],
    'installable': True,
    'application': True,
    'auto_install': False,
}