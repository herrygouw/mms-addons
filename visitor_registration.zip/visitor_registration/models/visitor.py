from odoo import models, fields, api

class Visitor(models.Model):
    _name = 'visitor.registration'
    _description = 'Visitor Registration'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    
    name = fields.Char(string='Visitor Name', required=True)
    email = fields.Char(string='Email')
    phone = fields.Char(string='Phone', required=True, tracking=True)
    company = fields.Char(string='Company', tracking=True)
    purpose = fields.Text(string='Purpose of Visit')
    visit_person = fields.Many2one('visit.person', string='Visit Person', required=True)
    visit_date = fields.Datetime(string='Visit Date', default=fields.Datetime.now)
    check_in = fields.Datetime(string='Check In Time')
    check_out = fields.Datetime(string='Check Out Time')
    state = fields.Selection([
        ('draft', 'Draft'),
        ('checked_in', 'Checked In'),
        ('checked_out', 'Checked Out'),
    ], string='Status', default='draft', tracking=True)
    
    def action_check_in(self):
        self.write({
            'check_in': fields.Datetime.now(),
            'state': 'checked_in'
        })
    
    def action_check_out(self):
        self.write({
            'check_out': fields.Datetime.now(),
            'state': 'checked_out'
        })
    
    def name_get(self):
        result = []
        for visitor in self:
            name = f"{visitor.name} ({visitor.company})" if visitor.company else visitor.name
            result.append((visitor.id, name))
        return result
    
    @api.onchange("visit_person")
    def onchange_visit_person(self):
        for rec in self:
            rec.company = rec.visit_person.company_name

