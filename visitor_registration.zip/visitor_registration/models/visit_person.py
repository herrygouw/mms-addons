from odoo import models, fields, api

class VisitPerson(models.Model):
    _name = 'visit.person'
    _description = 'Person to Visit'
    
    name = fields.Char(string='Name', required=True)
    # company_name = fields.Char(string='Company', required=True)
    company_name = fields.Char(string='Company')
    department = fields.Char(string='Department')
    email = fields.Char(string='Email')
    phone = fields.Char(string='Phone')
    active = fields.Boolean(string='Active', default=True)
    
    def name_get(self):
        result = []
        for person in self:
            name = f"{person.name} ({person.company_name}, {person.department})" if person.department else person.name
            result.append((person.id, name))
        return result